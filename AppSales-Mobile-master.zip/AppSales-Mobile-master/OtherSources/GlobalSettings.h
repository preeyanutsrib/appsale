//
//  GlobalSettings.h
//  AppSales
//
//  Created by Ole Zorn on 23.07.11.
//  Copyright 2011 omz:software. All rights reserved.
//

#define kSettingShowFiscalMonths		@"DashboardShowFiscalMonths"
#define kSettingDashboardSelectedTab	@"DashboardSelectedTab"
#define kSettingDashboardViewMode		@"DashboardViewMode"
#define kSettingShow14Days				@"DashboardShow14Days"
#define kSettingDashboardShowWeeks		@"DashboardShowWeeks"
#define kSettingDownloadPayments		@"DownloadPayments"

#define kSettingSelectedAccountID		@"SelectedAccountID"

#define ASWillShowPasscodeLockNotification	@"ASWillShowPasscodeLockNotification"